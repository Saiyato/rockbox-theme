-- Don't change this file!
-- It is automatically generated of button.h $Revision$
rb.buttons = {
	BUTTON_SELECT = 1,
	BUTTON_SCROLL_BACK = 32,
	BUTTON_LEFT = 4,
	BUTTON_RIGHT = 8,
	BUTTON_MAIN = 127,
	BUTTON_PLAY = 64,
	BUTTON_SCROLL_FWD = 16,
	BUTTON_MENU = 2,
	BUTTON_REL = 33554432,
	BUTTON_REPEAT = 67108864,
	BUTTON_TOUCHSCREEN = 134217728,
}
